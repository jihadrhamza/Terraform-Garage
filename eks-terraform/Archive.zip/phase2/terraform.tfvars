###############################################################################
# phase2/terraform.tfvars  -  same credentials as phase1
# DO NOT commit this file to git
###############################################################################

aws_access_key = "AKIAVCMS7FS4GMB2EOB5"
aws_secret_key = "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"
aws_region = "us-east-1"
