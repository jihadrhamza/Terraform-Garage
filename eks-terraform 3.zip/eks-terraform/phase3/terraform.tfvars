###############################################################################
# phase3/terraform.tfvars
# DO NOT commit this file to version control
###############################################################################

aws_access_key = "AKIARRWNS6DYITNLA7QS"
aws_secret_key = "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"
aws_region     = "us-east-1"

project_name = "myapp"
environment  = "sandbox"

github_organization = "Books-POCGroups"
github_repository   = "poc-book-mgmt-service"
github_branch       = "master"
github_token        = "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"

build_timeout      = 60
compute_type       = "BUILD_GENERAL1_MEDIUM"
log_retention_days = 30
