###############################################################################
# phase2/terraform.tfvars  -  same credentials as phase1
# DO NOT commit this file to git
###############################################################################

aws_access_key = "AKIARRWNS6DYITNLA7QS"
aws_secret_key = "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"
aws_region     = "us-east-1"
