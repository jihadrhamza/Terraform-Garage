locals {
  github_repo_url = "https://github.com/${var.github_organization}/${var.github_repository}.git"
}