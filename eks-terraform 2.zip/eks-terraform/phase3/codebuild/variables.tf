###############################################################################
# phase3/codebuild/variables.tf
###############################################################################

variable "project_name" {
  description = "Project Name"
  type        = string
}

variable "aws_region" {
  description = "AWS region"
  type        = string
}

variable "github_organization" {
  description = "GitHub Organization/User"
  type        = string
}

variable "github_repository" {
  description = "GitHub Repository"
  type        = string
}

variable "github_branch" {
  description = "GitHub Branch"
  type        = string
  default     = "main"
}

variable "github_token" {
  description = "GitHub personal access token for source credentials"
  type        = string
  sensitive   = true
}

variable "buildspec_path" {
  description = "Buildspec file path within the repository"
  type        = string
  default     = "buildspec.yml"
}

variable "cluster_name" {
  description = "EKS cluster name (from phase1 remote state)"
  type        = string
}

variable "vpc_id" {
  description = "VPC ID (from phase1 remote state)"
  type        = string
}

variable "private_subnet_ids" {
  description = "Private subnet IDs for CodeBuild VPC config (from phase1 remote state)"
  type        = list(string)
}

variable "tags" {
  type    = map(string)
  default = {}
}
