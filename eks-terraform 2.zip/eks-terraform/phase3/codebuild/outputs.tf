output "codebuild_project_name" {
  description = "Name of the CodeBuild runner project"
  value       = aws_codebuild_project.runner.name
}

output "codebuild_project_arn" {
  description = "ARN of the CodeBuild runner project"
  value       = aws_codebuild_project.runner.arn
}

output "codebuild_role_arn" {
  description = "ARN of the CodeBuild IAM role"
  value       = aws_iam_role.codebuild.arn
}

output "codebuild_sg_id" {
  description = "Security group ID attached to the CodeBuild VPC runner"
  value       = aws_security_group.codebuild.id
}

output "github_repository_url" {
  description = "Full GitHub repository URL used as the build source"
  value       = local.github_repo_url
}

output "webhook_url" {
  description = "GitHub webhook payload URL (registered automatically by CodeBuild)"
  value       = aws_codebuild_webhook.runner.payload_url
}
