###############################################################################
# phase3/codebuild/iam.tf
#
# IAM role for the CodeBuild runner agent.
# Permissions cover everything the buildspec needs to:
#   - Pull/push ECR images
#   - Authenticate to EKS and apply manifests (eks:DescribeCluster +
#     eks:AccessKubernetesApi / sts:AssumeRole for EKS auth)
#   - Write CloudWatch logs
#   - Read/write S3 (cache, artifacts)
#   - EC2 Describe (VPC config requirement — CodeBuild calls ec2:CreateNetworkInterface)
###############################################################################

data "aws_iam_policy_document" "codebuild_assume_role" {
  statement {
    effect = "Allow"

    principals {
      type        = "Service"
      identifiers = ["codebuild.amazonaws.com"]
    }

    actions = ["sts:AssumeRole"]
  }
}

resource "aws_iam_role" "codebuild" {
  name               = "${var.project_name}-codebuild-role"
  assume_role_policy = data.aws_iam_policy_document.codebuild_assume_role.json
  tags               = var.tags
}

resource "aws_iam_role_policy" "codebuild" {
  name = "${var.project_name}-codebuild-policy"
  role = aws_iam_role.codebuild.id

  policy = jsonencode({
    Version = "2012-10-17"

    Statement = [

      # -----------------------------------------------------------------
      # CloudWatch Logs — write build output
      # -----------------------------------------------------------------
      {
        Sid    = "Logs"
        Effect = "Allow"
        Action = [
          "logs:CreateLogGroup",
          "logs:CreateLogStream",
          "logs:PutLogEvents"
        ]
        Resource = "*"
      },

      # -----------------------------------------------------------------
      # S3 — build cache and optional artifact storage
      # -----------------------------------------------------------------
      {
        Sid    = "S3Cache"
        Effect = "Allow"
        Action = [
          "s3:GetObject",
          "s3:GetObjectVersion",
          "s3:PutObject",
          "s3:GetBucketAcl",
          "s3:GetBucketLocation"
        ]
        Resource = "*"
      },

      # -----------------------------------------------------------------
      # EC2 — REQUIRED when CodeBuild runs inside a VPC
      # CodeBuild calls CreateNetworkInterface/DeleteNetworkInterface
      # on the runner's behalf.
      # -----------------------------------------------------------------
      {
        Sid    = "EC2VpcAccess"
        Effect = "Allow"
        Action = [
          "ec2:CreateNetworkInterface",
          "ec2:DescribeDhcpOptions",
          "ec2:DescribeNetworkInterfaces",
          "ec2:DeleteNetworkInterface",
          "ec2:DescribeSubnets",
          "ec2:DescribeSecurityGroups",
          "ec2:DescribeVpcs",
          "ec2:CreateNetworkInterfacePermission"
        ]
        Resource = "*"
      },

      # -----------------------------------------------------------------
      # EKS — describe cluster to build a kubeconfig, then deploy
      # -----------------------------------------------------------------
      {
        Sid    = "EKSDescribe"
        Effect = "Allow"
        Action = [
          "eks:DescribeCluster",
          "eks:ListClusters",
          "eks:AccessKubernetesApi"
        ]
        Resource = "*"
      },

      # -----------------------------------------------------------------
      # STS — allows the runner to assume the EKS node/admin role so
      # kubectl can authenticate via aws eks get-token
      # -----------------------------------------------------------------
      {
        Sid      = "STSAssumeRole"
        Effect   = "Allow"
        Action   = ["sts:AssumeRole", "sts:GetCallerIdentity"]
        Resource = "*"
      },

      # -----------------------------------------------------------------
      # ECR — pull base images and push built images
      # -----------------------------------------------------------------
      {
        Sid    = "ECRAuth"
        Effect = "Allow"
        Action = ["ecr:GetAuthorizationToken"]
        Resource = "*"
      },
      {
        Sid    = "ECRReadWrite"
        Effect = "Allow"
        Action = [
          "ecr:BatchCheckLayerAvailability",
          "ecr:GetDownloadUrlForLayer",
          "ecr:BatchGetImage",
          "ecr:InitiateLayerUpload",
          "ecr:UploadLayerPart",
          "ecr:CompleteLayerUpload",
          "ecr:PutImage"
        ]
        Resource = "*"
      },

      # -----------------------------------------------------------------
      # SSM Parameter Store — read secrets/config at build time
      # -----------------------------------------------------------------
      {
        Sid    = "SSMParameters"
        Effect = "Allow"
        Action = [
          "ssm:GetParameter",
          "ssm:GetParameters",
          "ssm:GetParametersByPath"
        ]
        Resource = "*"
      }
    ]
  })
}
