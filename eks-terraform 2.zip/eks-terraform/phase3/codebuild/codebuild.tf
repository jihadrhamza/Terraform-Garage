###############################################################################
# phase3/codebuild/codebuild.tf
#
# CodeBuild project configured as a runner agent that deploys to EKS.
# - Runs inside the VPC so it can reach the private EKS API endpoint.
# - GitHub source credentials registered once per region via
#   aws_codebuild_source_credential (idempotent — CodeBuild allows only
#   one GITHUB credential per region; Terraform will adopt an existing one).
###############################################################################

# Register GitHub PAT so CodeBuild can clone private repos and report
# build status back to GitHub (required for runner-agent pattern).
resource "aws_codebuild_source_credential" "github" {
  auth_type   = "PERSONAL_ACCESS_TOKEN"
  server_type = "GITHUB"
  token       = var.github_token
}

# Security group for the CodeBuild runner — allows all outbound so the
# build can pull images, call AWS APIs, and reach the EKS endpoint.
resource "aws_security_group" "codebuild" {
  name        = "${var.project_name}-codebuild-sg"
  description = "CodeBuild runner agent egress"
  vpc_id      = var.vpc_id

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
    description = "Allow all outbound"
  }

  tags = merge(var.tags, { Name = "${var.project_name}-codebuild-sg" })
}

resource "aws_codebuild_project" "runner" {
  name          = "${var.project_name}-runner"
  description   = "Runner agent — builds and deploys to EKS"
  service_role  = aws_iam_role.codebuild.arn
  build_timeout = 60

  # Runner agents produce no uploadable artifacts.
  artifacts {
    type = "NO_ARTIFACTS"
  }

  environment {
    compute_type                = "BUILD_GENERAL1_MEDIUM"
    image                       = "aws/codebuild/standard:7.0"
    type                        = "LINUX_CONTAINER"
    privileged_mode             = true   # required for docker-in-docker builds
    image_pull_credentials_type = "CODEBUILD"

    environment_variable {
      name  = "AWS_DEFAULT_REGION"
      value = data.aws_region.current.name
    }

    environment_variable {
      name  = "EKS_CLUSTER_NAME"
      value = var.cluster_name
    }
  }

  # Place the runner inside the VPC so it can reach a private EKS endpoint.
  vpc_config {
    vpc_id             = var.vpc_id
    subnets            = var.private_subnet_ids
    security_group_ids = [aws_security_group.codebuild.id]
  }

  source {
    type                = "GITHUB"
    location            = local.github_repo_url
    git_clone_depth     = 1
    buildspec           = var.buildspec_path
    report_build_status = true  # post commit-status back to GitHub

    # Register a webhook so CodeBuild triggers on push/PR events.
    # Remove this block if you prefer to trigger builds manually or via CI.
  }

  source_version = var.github_branch

  logs_config {
    cloudwatch_logs {
      group_name  = aws_cloudwatch_log_group.codebuild.name
      stream_name = "runner"
      status      = "ENABLED"
    }
  }

  depends_on = [aws_codebuild_source_credential.github]

  tags = var.tags
}

# Webhook — triggers the runner on every push to the configured branch.
resource "aws_codebuild_webhook" "runner" {
  project_name = aws_codebuild_project.runner.name
  build_type   = "BUILD"

  filter_group {
    filter {
      type    = "EVENT"
      pattern = "PUSH"
    }

    filter {
      type    = "HEAD_REF"
      pattern = "refs/heads/${var.github_branch}"
    }
  }
}

data "aws_region" "current" {}
