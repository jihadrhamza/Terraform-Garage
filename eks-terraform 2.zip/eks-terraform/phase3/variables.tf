###############################################################################
# phase3/variables.tf
###############################################################################

variable "aws_access_key" {
  type      = string
  sensitive = true
}

variable "aws_secret_key" {
  type      = string
  sensitive = true
}

variable "aws_region" {
  type    = string
  default = "us-east-1"
}

variable "project_name" {
  description = "Project name (must match phase1)"
  type        = string
}

variable "environment" {
  description = "Environment name"
  type        = string
  default     = "sandbox"
}

variable "github_organization" {
  description = "GitHub Organization or username"
  type        = string
}

variable "github_repository" {
  description = "GitHub repository name"
  type        = string
}

variable "github_branch" {
  description = "Branch to build from"
  type        = string
  default     = "main"
}

variable "github_token" {
  description = "GitHub personal access token (needs repo + admin:repo_hook scopes)"
  type        = string
  sensitive   = true
}

variable "buildspec_path" {
  description = "Path to buildspec file within the repository"
  type        = string
  default     = "buildspec.yml"
}
