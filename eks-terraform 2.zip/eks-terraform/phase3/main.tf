###############################################################################
# PHASE 3 - CodeBuild Runner Agent
#
# Creates a CodeBuild project configured as a GitHub Actions runner agent
# that can deploy workloads to the EKS cluster provisioned in Phase 1.
#
# Reads Phase 1 remote state for: VPC, subnets, EKS cluster details.
###############################################################################

terraform {
  required_version = ">= 1.5.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}

provider "aws" {
  region     = var.aws_region
  access_key = var.aws_access_key
  secret_key = var.aws_secret_key
}

data "terraform_remote_state" "phase1" {
  backend = "local"
  config = {
    path = "${path.module}/../phase1/terraform.tfstate"
  }
}

locals {
  cluster_name       = data.terraform_remote_state.phase1.outputs.cluster_name
  vpc_id             = data.terraform_remote_state.phase1.outputs.vpc_id
  private_subnet_ids = data.terraform_remote_state.phase1.outputs.private_subnet_ids
}

module "codebuild" {
  source = "./codebuild"

  project_name          = var.project_name
  aws_region            = var.aws_region
  github_organization   = var.github_organization
  github_repository     = var.github_repository
  github_branch         = var.github_branch
  github_token          = var.github_token
  buildspec_path        = var.buildspec_path
  cluster_name          = local.cluster_name
  vpc_id                = local.vpc_id
  private_subnet_ids    = local.private_subnet_ids

  tags = {
    Project     = var.project_name
    Environment = var.environment
    ManagedBy   = "terraform"
    Phase       = "3"
  }
}
