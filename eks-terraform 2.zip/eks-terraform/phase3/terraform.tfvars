###############################################################################
# phase3/terraform.tfvars
# DO NOT commit this file to git
###############################################################################

aws_access_key = "PASTE_YOUR_ACCESS_KEY"
aws_secret_key = "PASTE_YOUR_SECRET_KEY"
aws_region     = "us-east-1"

project_name = "myapp"
environment  = "sandbox"

github_organization = "PASTE_YOUR_GITHUB_ORG"
github_repository   = "PASTE_YOUR_REPO_NAME"
github_branch       = "main"
github_token        = "PASTE_YOUR_GITHUB_PAT"

buildspec_path = "buildspec.yml"
