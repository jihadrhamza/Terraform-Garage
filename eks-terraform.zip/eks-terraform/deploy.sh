#!/bin/bash
###############################################################################
# deploy.sh  -  Deploys Phase 1 then Phase 2 automatically
# Usage:  chmod +x deploy.sh && ./deploy.sh
###############################################################################
set -euo pipefail

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'

info()    { echo -e "${GREEN}[INFO]${NC} $1"; }
warning() { echo -e "${YELLOW}[WARN]${NC} $1"; }
error()   { echo -e "${RED}[ERROR]${NC} $1"; exit 1; }

# Check credentials are set in tfvars
check_creds() {
  local dir=$1
  if grep -q "PASTE_YOUR" "$dir/terraform.tfvars" 2>/dev/null; then
    error "Please fill in aws_access_key and aws_secret_key in $dir/terraform.tfvars before running"
  fi
}

check_creds "phase1"
check_creds "phase2"

###############################################################################
# PHASE 1 - AWS Infrastructure
###############################################################################
info "========== PHASE 1: AWS Infrastructure =========="
cd phase1

info "Initializing Phase 1..."
terraform init -upgrade

info "Planning Phase 1..."
terraform plan -out=phase1.tfplan

info "Applying Phase 1 (this takes ~15 minutes for EKS)..."
terraform apply phase1.tfplan

info "Phase 1 complete. Key outputs:"
terraform output kubectl_ssm_command
terraform output alb_dns_name
terraform output kubeconfig_command

cd ..

###############################################################################
# PHASE 2 - Helm / Kubernetes resources
###############################################################################
info "========== PHASE 2: Helm / Kubernetes =========="
cd phase2

info "Initializing Phase 2..."
terraform init -upgrade

info "Planning Phase 2..."
terraform plan -out=phase2.tfplan

info "Applying Phase 2..."
terraform apply phase2.tfplan

cd ..

###############################################################################
# Done
###############################################################################
info "=========================================="
info "Deployment complete!"
info ""
info "Connect to kubectl instance:"
cd phase1 && terraform output -raw kubectl_ssm_command && cd ..
info ""
info "Point your domain CNAME to:"
cd phase1 && terraform output -raw alb_dns_name && cd ..
info ""
info "To configure kubectl locally:"
cd phase1 && terraform output -raw kubeconfig_command && cd ..
