###############################################################################
# phase2/terraform.tfvars  -  same credentials as phase1
# DO NOT commit this file to git
###############################################################################

aws_access_key = "AKIA6ODUZT2I34PG5LLX"
aws_secret_key = "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"
aws_region     = "us-east-1"
