###############################################################################
# modules/eks/variables.tf
###############################################################################

variable "project_name"       { type = string }
variable "environment"        { type = string }
variable "cluster_name"       { type = string }
variable "cluster_version"    { type = string }
variable "vpc_id"             { type = string }
variable "private_subnet_ids" { type = list(string) }
variable "public_subnet_ids"  { type = list(string) }
variable "node_instance_type" { type = string }
variable "node_desired_size"  { type = number }
variable "node_min_size"      { type = number }
variable "node_max_size"      { type = number }
variable "aws_account_id"     { type = string }

variable "kubectl_sg_id" {
  description = "Security group ID of the kubectl management instance"
  type        = string
}
