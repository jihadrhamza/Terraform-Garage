#!/bin/bash
###############################################################################
# destroy.sh  -  Tears down Phase 2 then Phase 1 in correct order
# Usage:  chmod +x destroy.sh && ./destroy.sh
###############################################################################
set -euo pipefail

GREEN='\033[0;32m'; NC='\033[0m'
info() { echo -e "${GREEN}[INFO]${NC} $1"; }

info "========== Destroying Phase 2: Helm resources =========="
cd phase2
terraform destroy -auto-approve
cd ..

info "========== Destroying Phase 1: AWS Infrastructure =========="
cd phase1
terraform destroy -auto-approve
cd ..

info "All resources destroyed."
