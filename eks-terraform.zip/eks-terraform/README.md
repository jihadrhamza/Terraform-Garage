# EKS Two-Phase Terraform Deployment

Splits infrastructure into two phases to avoid the Kubernetes provider
chicken-and-egg problem — no manual `aws-auth` patching needed.

```
eks-terraform/
  phase1/          # AWS infra: VPC, EKS, nodes, kubectl EC2, ALB, IAM, access entries
  phase2/          # Helm: AWS Load Balancer Controller
  k8s/             # Kubernetes manifests (sample app)
  deploy.sh        # Runs both phases automatically
  destroy.sh       # Tears down both phases in correct order
```

---

## Quick Start

### 1. Set credentials (both phases)

Edit `phase1/terraform.tfvars`:
```hcl
aws_access_key = "YOUR_KEY"
aws_secret_key = "YOUR_SECRET"
```

Edit `phase2/terraform.tfvars`:
```hcl
aws_access_key = "YOUR_KEY"
aws_secret_key = "YOUR_SECRET"
```

### 2. Deploy everything (one command)

```bash
chmod +x deploy.sh destroy.sh
./deploy.sh
```

Phase 1 takes ~15 minutes (EKS cluster creation).
Phase 2 takes ~2 minutes (Helm chart install).

### 3. Connect to kubectl instance via SSM

```bash
# Get the command from phase1 output:
cd phase1 && terraform output kubectl_ssm_command

# Example:
aws ssm start-session --target i-0abc1234 --region us-east-1
```

Once in the SSM session:
```bash
# Configure kubectl (one-time, already done by userdata but run if needed)
aws eks update-kubeconfig --name myapp-eks --region us-east-1

# Verify nodes
kubectl get nodes
```

No `aws-auth` patching needed — Phase 1 uses `aws_eks_access_entry` (EKS
access entries API) to grant the kubectl instance cluster-admin automatically.

### 4. Deploy a sample app

```bash
kubectl apply -f ../k8s/sample-app.yaml
kubectl get ingress -n sample-app   # ALB DNS shown after ~2 min
```

### 5. Point your domain to ALB

```bash
cd phase1 && terraform output alb_dns_name
```
Create a CNAME record pointing your domain to that DNS name.
For Route 53, use an Alias A record with the `alb_zone_id` output.

---

## Add HTTPS (ACM)

1. Create/validate a certificate in AWS ACM
2. Add the ARN to `phase1/terraform.tfvars`:
```hcl
acm_certificate_arn = "arn:aws:acm:us-east-1:ACCOUNT:certificate/ID"
```
3. `cd phase1 && terraform apply` — HTTPS listener is added automatically

---

## How Phase 2 gets Phase 1 data

Phase 2 uses `terraform_remote_state` to read Phase 1's local state file:
```hcl
data "terraform_remote_state" "phase1" {
  backend = "local"
  config  = { path = "../phase1/terraform.tfstate" }
}
```
No manual copy-paste of cluster endpoints, ARNs, or IDs between phases.

---

## Teardown

```bash
./destroy.sh
```

Always destroys Phase 2 first (Helm releases hold AWS resources like ENIs),
then Phase 1.

---

## Why Two Phases?

Terraform initializes ALL providers at plan time. If the Kubernetes/Helm
provider is configured in the same workspace as EKS creation, it tries to
connect to a cluster that doesn't exist yet → error.

Splitting into two workspaces means:
- Phase 1: only AWS provider (no K8s connection needed at plan time)
- Phase 2: cluster already exists when Helm provider initializes
- `aws_eks_access_entry` in Phase 1 handles auth — no manual aws-auth editing
